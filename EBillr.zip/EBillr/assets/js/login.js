document.addEventListener('DOMContentLoaded', () => {
    const githubBtn = document.getElementById('github-login-btn');

    // Check if already logged in
    if (checkAuth()) {
        window.location.href = 'ebillr.html';
        return;
    }

    // Check for auth errors
    const error = localStorage.getItem('github_auth_error');
    if (error) {
        showError(error);
        localStorage.removeItem('github_auth_error');
    }

    // Setup GitHub OAuth with PKCE
    const state = generateStateToken();
    const codeVerifier = generateCodeVerifier();

    localStorage.setItem('github_auth_state', state);
    localStorage.setItem('github_code_verifier', codeVerifier);

    const codeChallenge = generateCodeChallenge(codeVerifier);
    const redirectUri = encodeURIComponent(window.location.origin + '/auth-callback.html');

    // Update GitHub button href with all security parameters
    githubBtn.href = `https://github.com/login/oauth/authorize?client_id=Ov23liQgRHKpfR6JJzHi&redirect_uri=${redirectUri}&scope=user:email&state=${state}&code_challenge=${codeChallenge}&code_challenge_method=S256`;

    // Store the current time to prevent replay attacks
    githubBtn.addEventListener('click', () => {
        localStorage.setItem('github_auth_time', Date.now());
    });
});
