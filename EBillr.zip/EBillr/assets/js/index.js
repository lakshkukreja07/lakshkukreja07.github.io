document.addEventListener('DOMContentLoaded', () => {
  const words = document.querySelectorAll('.typewriter-word span');
  words.forEach(word => {
    word.style.willChange = 'transform, opacity';
  });

  const tips = [
    "Pro Tip: Press Ctrl+D to bookmark!",
    "Fun Fact: EBillr started as a side project.",
    "Tip: Works best in dark mode 😉",
    "Fact: Built entirely with open source tools.",
    "Fun Tip: Try resizing — it's fully responsive!"
  ];

  const tipElement = document.getElementById("fun-tip");
  if (tipElement) {
    let index = 0;
    tipElement.textContent = tips[index];
    setInterval(() => {
      index = (index + 1) % tips.length;
      tipElement.textContent = tips[index];
    }, 5000);
  }
});
