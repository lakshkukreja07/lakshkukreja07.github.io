const facts = [
    "EBillr V1.6.2.700",
    "TIP: Store Bills Securely With EBillr",
    "FACT: The First Invoice Dates Back To 5000 BC",
    "TIP: We Provide Dark & Light Mode Support",
    "FACT: Modern, Aesthetic UI Design For Easy Usage",
];
function rotateFact() {
    const factBox = document.getElementById("fun-fact");
    if (!factBox) return;
    const fact = facts[Math.floor(Math.random() * facts.length)];
    factBox.textContent = fact;
}
rotateFact();
setInterval(rotateFact, 6000);
