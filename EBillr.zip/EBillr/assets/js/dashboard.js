// assets/js/dashboard.js
// Implements the UI sketched by user: left analytics, center invoice creation with dynamic fields,
// right summary + actions; mobile stacked. Uses assets/userdata.json as backbone.
// Drive actions expect localStorage.googleAccessToken (OAuth token).

document.addEventListener('DOMContentLoaded', () => {
    // DOM refs
    const sidebarToggle = document.getElementById('sidebarToggle');
    const leftPanel = document.getElementById('leftPanel');
    const centerPanel = document.getElementById('centerPanel') || document.getElementById('centerPanel');
    const rightPanel = document.getElementById('rightPanel');

    const bizInfo = document.getElementById('bizInfo');
    const dynamicHeader = document.getElementById('dynamicHeader');
    const itemsBody = document.getElementById('itemsBody');
    const addItemBtn = document.getElementById('addItem');

    const subtotalEl = document.getElementById('subtotal');
    const taxAmtEl = document.getElementById('taxAmt');
    const discountAmtEl = document.getElementById('discountAmt');
    const totalEl = document.getElementById('total');

    const saveJsonDrive = document.getElementById('saveJsonDrive');
    const saveHtmlDrive = document.getElementById('saveHtmlDrive');
    const printInvoice = document.getElementById('printInvoice');
    const resetInvoice = document.getElementById('resetInvoice');
    const mobileSave = document.getElementById('mobileSave');
    const mobilePrint = document.getElementById('mobilePrint');

    const notes = document.getElementById('notes');
    const taxInput = document.getElementById('taxInput') || document.getElementById('taxInput');
    const discountInput = document.getElementById('discountInput') || document.getElementById('discountInput');

    const serverClockEl = document.getElementById('serverClock');
    const currencyCodeEl = document.getElementById('currencyCode') || document.getElementById('currencyCode');
    const currencySymbolEl = document.getElementById('currencySymbol');

    const refreshDriveList = document.getElementById('refreshDriveList');
    const driveList = document.getElementById('driveList');
    const analyticsCount = document.getElementById('analyticsCount');
    const analyticsLast = document.getElementById('analyticsLast');

    // Settings
    const topSettingsBtn = document.getElementById('topSettingsBtn');
    const settingsSection = document.getElementById('settings');
    const s_buisness_name = document.getElementById('s_buisness_name');
    const s_buisness_message = document.getElementById('s_buisness_message');
    const s_buisness_address = document.getElementById('s_buisness_address');
    const s_user_timezone = document.getElementById('s_user_timezone');
    const s_user_country = document.getElementById('s_user_country');
    const s_user_currency = document.getElementById('s_user_currency');
    const s_user_fields = document.getElementById('s_user_fields');
    const saveSettingsLocal = document.getElementById('saveSettingsLocal');
    const saveSettingsDrive = document.getElementById('saveSettingsDrive');
    const sessionModal = document.getElementById('sessionModal');
    const sessionModalClose = document.getElementById('sessionModalClose');

    // invoice meta
    const invoiceNumber = document.getElementById('invoiceNumber');
    const invoiceDate = document.getElementById('invoiceDate');
    const customerName = document.getElementById('customerName');
    const customerId = document.getElementById('customerId');

    // state
    let userdata = null;
    let fields = ['weight', 'price', 'quantity']; // default
    let qtyField = 'quantity';
    let priceField = 'price';
    let currency = 'INR';
    let currencySymbol = '₹';
    let serverTime = Date.now();
    let serverTicker = null;

    // helpers
    const getAccessToken = () => localStorage.getItem('googleAccessToken') || null;
    const requireToken = () => {
        const t = getAccessToken();
        if (!t) {
            sessionModal.style.display = 'flex';
            return null;
        }
        sessionModal.style.display = 'none';
        return t;
    };
    sessionModalClose?.addEventListener('click', () => sessionModal.style.display = 'none');

    const fetchJSON = async (p) => {
        const r = await fetch(p, { cache: 'no-store' });
        if (!r.ok) throw new Error('Fetch failed ' + r.status);
        return r.json();
    };

    // drive helpers (multipart)
    const driveUploadMultipart = async (filename, mimeType, content) => {
        const token = requireToken();
        if (!token) throw new Error('No token');
        const meta = { name: filename, mimeType };
        const boundary = 'ebillr_' + Math.random().toString(36).slice(2);
        const body =
            `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(meta)}\r\n` +
            `--${boundary}\r\nContent-Type: ${mimeType}\r\n\r\n${content}\r\n` +
            `--${boundary}--`;
        const res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
            method: 'POST',
            headers: { 'Authorization': 'Bearer ' + token, 'Content-Type': 'multipart/related; boundary=' + boundary },
            body
        });
        if (!res.ok) {
            const txt = await res.text();
            throw new Error('Upload failed: ' + res.status + ' ' + txt);
        }
        return res.json();
    };

    const driveListInvoices = async () => {
        const token = requireToken();
        if (!token) return null;
        const q = encodeURIComponent("name contains 'EBillr_Invoice_' and trashed=false");
        const url = `https://www.googleapis.com/drive/v3/files?q=${q}&fields=files(id,name,modifiedTime,size)&orderBy=modifiedTime desc`;
        const res = await fetch(url, { headers: { 'Authorization': 'Bearer ' + token } });
        if (!res.ok) throw new Error('List failed');
        return res.json();
    };

    const driveDownload = async (id) => {
        const token = requireToken();
        if (!token) return null;
        const url = `https://www.googleapis.com/drive/v3/files/${id}?alt=media`;
        const res = await fetch(url, { headers: { 'Authorization': 'Bearer ' + token } });
        if (!res.ok) throw new Error('Download failed');
        return res.text();
    };

    const driveAbout = async () => {
        const token = getAccessToken();
        if (!token) throw new Error('No token');
        const url = 'https://www.googleapis.com/drive/v3/about?fields=user';
        const res = await fetch(url, { headers: { 'Authorization': 'Bearer ' + token } });
        if (!res.ok) throw new Error('About failed');
        return { json: await res.json(), dateHeader: res.headers.get('date') || res.headers.get('Date') };
    };

    // currency format
    const formatCurrency = (n) => {
        try {
            return new Intl.NumberFormat(undefined, { style: 'currency', currency }).format(Number(n || 0));
        } catch {
            return (Number(n || 0)).toFixed(2);
        }
    };
    const extractCurrencySymbol = () => {
        try {
            const parts = new Intl.NumberFormat(undefined, { style: 'currency', currency }).formatToParts(1);
            const p = parts.find(x => x.type === 'currency');
            return p ? p.value : currency;
        } catch {
            const map = { INR: '₹', USD: '$', EUR: '€', GBP: '£' };
            return map[currency] || currency;
        }
    };

    // load userdata.json (or local override)
    const loadUserData = async () => {
        const local = localStorage.getItem('ebillr_userdata');
        if (local) {
            try { userdata = JSON.parse(local); return; } catch { }
        }
        try {
            userdata = await fetchJSON('assets/userdata.json');
        } catch {
            userdata = {
                buisness_name: 'EBillr',
                buisness_message: 'Thanks for your business',
                buisness_address: '',
                last_customer_id: 0,
                user_timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
                user_country: 'IN',
                user_currency: 'INR',
                user_fields: 'weight, price, quantity'
            };
        }
    };

    const applyUserData = () => {
        // header info & biz info
        document.getElementById('bizInfo').innerHTML =
            `<div class="font-semibold">${userdata.buisness_name}</div><div class="opacity-70">${userdata.buisness_address}</div><div class="italic mt-1 opacity-70">${userdata.buisness_message}</div>`;
        document.getElementById('bizNameLabel').textContent = userdata.buisness_name || 'EBillr';

        // fields and currency
        fields = (userdata.user_fields || 'weight, price, quantity').split(',').map(s => s.trim()).filter(Boolean);
        qtyField = fields.find(f => /qty|quantity/i.test(f)) || 'quantity';
        priceField = fields.find(f => /price|rate|amount/i.test(f)) || 'price';
        currency = userdata.user_currency || 'INR';
        currencySymbol = extractCurrencySymbol();
        currencySymbolEl.textContent = currencySymbol;
        if (currencyCodeEl) currencyCodeEl.textContent = currency;
        document.getElementById('tzLabel').textContent = 'Timezone: ' + (userdata.user_timezone || Intl.DateTimeFormat().resolvedOptions().timeZone);

        // invoice meta defaults
        const nextId = (Number(userdata.last_customer_id || 0) + 1);
        if (invoiceNumber) invoiceNumber.value = `${(userdata.buisness_name || 'EBillr').replace(/\s+/g, '')}-${String(nextId).padStart(4, '0')}`;
        if (invoiceDate) invoiceDate.value = new Date().toISOString().slice(0, 10);
        if (customerId) customerId.value = String(nextId);

        // settings inputs
        s_buisness_name.value = userdata.buisness_name || '';
        s_buisness_message.value = userdata.buisness_message || '';
        s_buisness_address.value = userdata.buisness_address || '';
        s_user_timezone.value = userdata.user_timezone || '';
        s_user_country.value = userdata.user_country || '';
        s_user_currency.value = userdata.user_currency || '';
        s_user_fields.value = userdata.user_fields || '';

        // build header & initial row(s)
        buildHeader();
        itemsBody.innerHTML = '';
        addRow();
        recalcTotals();
    };

    const buildHeader = () => {
        dynamicHeader.innerHTML = '';
        fields.forEach(f => {
            const th = document.createElement('th');
            th.className = 'text-left py-2 capitalize';
            th.textContent = f;
            dynamicHeader.appendChild(th);
        });
        const thAmt = document.createElement('th'); thAmt.className = 'text-right py-2'; thAmt.textContent = 'Amount';
        dynamicHeader.appendChild(thAmt);
        dynamicHeader.appendChild(document.createElement('th'));
    };

    // add row
    const createInput = (val = '') => {
        const inp = document.createElement('input');
        inp.type = 'text';
        inp.className = 'w-full px-2 py-1 rounded border';
        inp.value = val;
        return inp;
    };

    const addRow = (values = {}) => {
        const tr = document.createElement('tr');
        const inputs = {};
        fields.forEach(f => {
            const td = document.createElement('td'); td.className = 'py-2';
            const inp = createInput(values[f] || '');
            inp.dataset.field = f;
            td.appendChild(inp);
            tr.appendChild(td);
            inputs[f] = inp;
        });
        const tdAmt = document.createElement('td'); tdAmt.className = 'text-right py-2';
        const spanAmt = document.createElement('span'); spanAmt.textContent = formatCurrency(0);
        tdAmt.appendChild(spanAmt);
        tr.appendChild(tdAmt);
        const tdAct = document.createElement('td'); tdAct.className = 'py-2 text-center';
        const del = document.createElement('button'); del.className = 'action-btn'; del.textContent = 'Delete';
        del.addEventListener('click', () => { tr.remove(); recalcTotals(); });
        tdAct.appendChild(del);
        tr.appendChild(tdAct);

        // listeners
        const recalcRow = () => {
            const qty = Number((inputs[qtyField]?.value || '0').toString().replace(/[^0-9.-]/g, '')) || 0;
            const price = Number((inputs[priceField]?.value || '0').toString().replace(/[^0-9.-]/g, '')) || 0;
            const amt = qty * price;
            spanAmt.textContent = formatCurrency(amt);
            recalcTotals();
        };
        Object.values(inputs).forEach(i => i.addEventListener('input', recalcRow));
        itemsBody.appendChild(tr);
        recalcRow();
    };

    // totals & preview
    const recalcTotals = () => {
        let subtotal = 0;
        itemsBody.querySelectorAll('tr').forEach(tr => {
            const amtText = tr.querySelector('td:nth-last-child(2) span').textContent || '0';
            subtotal += parseFloat(amtText.replace(/[^0-9.-]+/g, '')) || 0;
        });
        const taxPct = Number(taxInput?.value || 0) / 100;
        const taxAmt = subtotal * taxPct;
        const discount = Number(discountInput?.value || 0) || 0;
        const total = Math.max(0, subtotal + taxAmt - discount);

        subtotalEl.textContent = formatCurrency(subtotal);
        taxAmtEl.textContent = formatCurrency(taxAmt);
        discountAmtEl.textContent = formatCurrency(discount);
        totalEl.textContent = formatCurrency(total);

        renderPreview();
    };

    const collectInvoice = () => {
        const items = [];
        itemsBody.querySelectorAll('tr').forEach(tr => {
            const row = {};
            tr.querySelectorAll('input').forEach(inp => { row[inp.dataset.field] = inp.value; });
            const amtText = tr.querySelector('td:nth-last-child(2) span').textContent || '0';
            row._amount = parseFloat(amtText.replace(/[^0-9.-]+/g, '')) || 0;
            items.push(row);
        });
        return {
            business: { name: userdata.buisness_name, address: userdata.buisness_address, message: userdata.buisness_message },
            meta: { invoice_number: invoiceNumber?.value || '', date: invoiceDate?.value || '', currency, server_time: new Date(serverTime).toISOString() },
            customer: { name: customerName?.value || '', id: customerId?.value || '' },
            items,
            totals: { subtotal: subtotalEl.textContent, tax: taxInput?.value || 0, tax_amount: taxAmtEl.textContent, discount: discountInput?.value || 0, total: totalEl.textContent },
            notes: notes?.value || ''
        };
    };

    const renderPreview = () => {
        const json = collectInvoice();
        let h = `<div class="font-semibold">${userdata.buisness_name}</div><div class="opacity-70">${userdata.buisness_address}</div><div class="italic mt-1 opacity-70">${userdata.buisness_message}</div><hr class="my-2" />`;
        h += `<table style="width:100%;border-collapse:collapse"><thead><tr>`;
        fields.forEach(f => h += `<th style="text-align:left;padding:6px">${f}</th>`);
        h += `<th style="text-align:right;padding:6px">Amount</th></tr></thead><tbody>`;
        json.items.forEach(it => {
            h += '<tr>';
            fields.forEach(f => h += `<td style="padding:6px">${it[f] || ''}</td>`);
            h += `<td style="text-align:right;padding:6px">${formatCurrency(it._amount)}</td></tr>`;
        });
        h += `</tbody></table><div class="mt-2 text-right">Total: <strong>${json.totals.total}</strong></div>`;
        document.getElementById('invoicePreview').innerHTML = h;
    };

    // save/print
    const saveJSONToDrive = async () => {
        try {
            const payload = collectInvoice();
            const fname = `EBillr_Invoice_${Date.now()}.json`;
            await driveUploadMultipart(fname, 'application/json', JSON.stringify(payload, null, 2));
            alert('Saved to Drive: ' + fname);
        } catch (e) { alert('Save failed: ' + (e.message || e)); }
    };

    const saveHTMLToDrive = async () => {
        try {
            renderPreview();
            const html = `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Invoice</title></head><body>${document.getElementById('invoicePreview').innerHTML}</body></html>`;
            const fname = `EBillr_Invoice_${Date.now()}.html`;
            await driveUploadMultipart(fname, 'text/html', html);
            alert('Saved to Drive: ' + fname);
        } catch (e) { alert('Save failed: ' + (e.message || e)); }
    };

    const doPrint = () => {
        renderPreview();
        const w = window.open('', '_blank');
        w.document.write(`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Invoice</title></head><body>${document.getElementById('invoicePreview').innerHTML}</body></html>`);
        w.document.close(); w.focus(); w.print();
    };

    const resetInvoice = () => {
        userdata.last_customer_id = (Number(userdata.last_customer_id) || 0) + 1;
        localStorage.setItem('ebillr_userdata', JSON.stringify(userdata));
        itemsBody.innerHTML = ''; addRow(); recalcTotals();
        const nextId = Number(userdata.last_customer_id || 0) + 1;
        invoiceNumber.value = `${(userdata.buisness_name || 'EBillr').replace(/\s+/g, '')}-${String(nextId).padStart(4, '0')}`;
        customerId.value = String(nextId);
        alert('New invoice started (local increment). Save to Drive to persist globally.');
    };

    // drive listing
    const renderDriveFiles = (files) => {
        if (!files || files.length === 0) { driveList.className = 'data-placeholder'; driveList.textContent = 'No invoices found'; analyticsCount.textContent = '0'; analyticsLast.textContent = '—'; return; }
        analyticsCount.textContent = files.length;
        analyticsLast.textContent = files[0]?.modifiedTime ? new Date(files[0].modifiedTime).toLocaleString() : '—';

        driveList.innerHTML = `<div class="overflow-x-auto"><table class="w-full text-sm"><thead><tr><th>Name</th><th>Modified</th><th>Size</th><th>Action</th></tr></thead><tbody>` +
            files.map(f => `<tr>
        <td>${f.name}</td>
        <td>${new Date(f.modifiedTime).toLocaleString()}</td>
        <td>${f.size ? (Number(f.size) / 1024).toFixed(1) + ' KB' : '-'}</td>
        <td><button class="action-btn open-drive-file" data-id="${f.id}" data-name="${f.name}">Open</button></td>
      </tr>`).join('') + `</tbody></table></div>`;

        driveList.querySelectorAll('.open-drive-file').forEach(btn => {
            btn.addEventListener('click', async () => {
                try {
                    const id = btn.dataset.id; const name = btn.dataset.name || '';
                    const text = await driveDownload(id);
                    if (name.endsWith('.json')) {
                        const obj = JSON.parse(text);
                        loadInvoiceFromJSON(obj);
                    } else {
                        const w = window.open('', '_blank'); w.document.write(text); w.document.close();
                    }
                } catch (e) { alert('Open failed: ' + (e.message || e)); }
            });
        });
    };

    const loadInvoiceFromJSON = (data) => {
        try {
            if (data.raw_userdata && data.raw_userdata.user_fields) {
                userdata.user_fields = data.raw_userdata.user_fields;
                applyUserData(); // rebuild UI
            }
            itemsBody.innerHTML = '';
            (data.items || []).forEach(it => addRow(it));
            if ((data.items || []).length === 0) addRow();
            taxInput.value = data.totals?.tax || 0;
            discountInput.value = data.totals?.discount || 0;
            recalcTotals();
            window.scrollTo({ top: 0 });
        } catch (e) { alert('Load invoice error'); }
    };

    // settings
    const pushSettingsFromUI = () => {
        userdata.buisness_name = s_buisness_name.value.trim();
        userdata.buisness_message = s_buisness_message.value.trim();
        userdata.buisness_address = s_buisness_address.value.trim();
        userdata.user_timezone = s_user_timezone.value.trim();
        userdata.user_country = s_user_country.value.trim();
        userdata.user_currency = s_user_currency.value.trim();
        userdata.user_fields = s_user_fields.value.trim();
    };

    const saveSettingsLocalFn = () => {
        pushSettingsFromUI();
        localStorage.setItem('ebillr_userdata', JSON.stringify(userdata));
        applyUserData();
        alert('Saved locally.');
    };

    const saveSettingsDriveFn = async () => {
        try {
            pushSettingsFromUI();
            await driveUploadMultipart('userdata.json', 'application/json', JSON.stringify(userdata, null, 2));
            alert('userdata.json saved to Drive.');
        } catch (e) { alert('Drive save failed: ' + (e.message || e)); }
    };

    // UI events
    addItemBtn.addEventListener('click', () => addRow());
    taxInput?.addEventListener('input', recalcTotals);
    discountInput?.addEventListener('input', recalcTotals);

    saveJsonDrive?.addEventListener('click', saveJSONToDrive);
    saveHtmlDrive?.addEventListener('click', saveHTMLToDrive);
    printInvoice?.addEventListener('click', doPrint);
    resetInvoice?.addEventListener('click', resetInvoice);
    mobileSave?.addEventListener('click', saveJSONToDrive);
    mobilePrint?.addEventListener('click', doPrint);

    refreshDriveList?.addEventListener('click', async () => {
        driveList.className = 'data-placeholder'; driveList.textContent = 'Loading...';
        try {
            const data = await driveListInvoices();
            renderDriveFiles(data?.files || []);
        } catch (e) { driveList.textContent = 'Failed: ' + (e.message || e); }
    });

    saveSettingsLocal?.addEventListener('click', saveSettingsLocalFn);
    saveSettingsDrive?.addEventListener('click', saveSettingsDriveFn);

    topSettingsBtn?.addEventListener('click', () => {
        // show settings section
        settingsSection.classList.remove('hidden');
        window.scrollTo({ top: 0 });
    });

    sidebarToggle?.addEventListener('click', () => leftPanel.classList.toggle('hidden'));

    // server time sync
    const syncServerTimeAndCurrency = async () => {
        const token = getAccessToken();
        if (!token) {
            serverTime = Date.now();
            startClock();
            return;
        }
        try {
            const { json, dateHeader } = await driveAbout();
            if (dateHeader) { const d = new Date(dateHeader); if (!isNaN(d)) serverTime = d.getTime(); }
            else serverTime = Date.now();
            currency = userdata.user_currency || currency;
            currencySymbol = extractCurrencySymbol();
            currencySymbolEl.textContent = currencySymbol;
            if (currencyCodeEl) currencyCodeEl.textContent = currency;
            startClock();
        } catch (e) {
            serverTime = Date.now();
            startClock();
        }
    };

    const startClock = () => {
        if (serverTicker) clearInterval(serverTicker);
        const tick = () => {
            serverTime += 1000;
            const d = new Date(serverTime);
            const hh = String(d.getHours()).padStart(2, '0');
            const mm = String(d.getMinutes()).padStart(2, '0');
            const ss = String(d.getSeconds()).padStart(2, '0');
            serverClockEl.textContent = `${hh}:${mm}:${ss}`;
        };
        tick();
        serverTicker = setInterval(tick, 1000);
    };

    // init
    const init = async () => {
        await loadUserData();
        applyUserData();
        await syncServerTimeAndCurrency();
    };

    // run
    init();
});
