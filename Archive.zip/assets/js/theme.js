// assets/js/theme.js
document.addEventListener('DOMContentLoaded', () => {
    const html = document.documentElement;
    const header = document.querySelector('header');
    const desktopBtn = document.getElementById('theme-toggle');
    const mobileBtn = document.getElementById('theme-toggle-mobile');
    const systemDark = window.matchMedia('(prefers-color-scheme: dark)');

    // ---- helpers ----
    const apply = (mode, persist) => {
        const value = mode === 'dark' ? 'dark' : 'light';
        html.setAttribute('data-theme', value);
        if (persist) localStorage.setItem('theme', value);
    };

    const init = () => {
        const saved = localStorage.getItem('theme');
        if (saved === 'dark' || saved === 'light') {
            apply(saved, false);
        } else {
            // no user preference yet → follow system (no persist)
            apply(systemDark.matches ? 'dark' : 'light', false);
        }
    };

    const toggle = () => {
        const current = html.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
        apply(current === 'dark' ? 'light' : 'dark', true);
        userOverrode = true;
    };

    // ---- init theme ----
    init();

    // Follow system *only* until user manually toggles
    let userOverrode = !!localStorage.getItem('theme');
    if (systemDark.addEventListener) {
        systemDark.addEventListener('change', (e) => {
            if (!userOverrode) apply(e.matches ? 'dark' : 'light', false);
        });
    } else if (systemDark.addListener) {
        // Safari fallback
        systemDark.addListener((e) => {
            if (!userOverrode) apply(e.matches ? 'dark' : 'light', false);
        });
    }

    // Wire footer buttons (same IDs as login.html footer)
    [desktopBtn, mobileBtn].forEach((btn) => btn?.addEventListener('click', toggle));

    // Header scroll effect (kept from your original)
    window.addEventListener('scroll', () => {
        if (!header) return;
        if (window.scrollY > 10) header.classList.add('scrolled');
        else header.classList.remove('scrolled');
    }, { passive: true });
});
