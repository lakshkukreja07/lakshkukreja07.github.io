document.addEventListener('DOMContentLoaded', () => {
    const html = document.documentElement;
    const header = document.querySelector('header');
    const themeToggleDesktop = document.getElementById('theme-toggle');
    const themeToggleMobile = document.getElementById('theme-toggle-mobile');
    const darkQuery = window.matchMedia('(prefers-color-scheme: dark)');

    const applyTheme = (isDark) => {
        html.setAttribute('data-theme', isDark ? 'dark' : 'light');
    };

    // Initial theme based on system preference
    applyTheme(darkQuery.matches);

    // Watch system changes
    darkQuery.addEventListener('change', (e) => {
        applyTheme(e.matches);
    });

    // Toggle theme (desktop + mobile)
    const toggleTheme = () => {
        const current = html.getAttribute('data-theme');
        applyTheme(current === 'dark' ? false : true);
    };

    themeToggleDesktop?.addEventListener('click', toggleTheme);
    themeToggleMobile?.addEventListener('click', toggleTheme);

    // Header scroll effect
    window.addEventListener('scroll', () => {
        if (window.scrollY > 10) {
            header?.classList.add('scrolled');
        } else {
            header?.classList.remove('scrolled');
        }
    });
});
